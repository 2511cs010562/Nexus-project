import { useState, useEffect } from 'react';
import { User, Role, Connection } from './types';
import Auth from './components/Auth';
import StudentDashboard from './components/StudentDashboard';
import MentorDashboard from './components/MentorDashboard';
import ChatRoom from './components/ChatRoom';
import Navbar from './components/Navbar';
import { io, Socket } from 'socket.io-client';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'));
  const [view, setView] = useState<'dashboard' | 'chat'>('dashboard');
  const [activeChat, setActiveChat] = useState<Connection | null>(null);
  const [socket, setSocket] = useState<Socket | null>(null);

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser && token) {
      const parsedUser = JSON.parse(storedUser);
      // Verify user still exists in DB
      fetch(`/api/auth/verify-session/${parsedUser.id}`)
        .then(res => {
          if (res.ok) {
            setUser(parsedUser);
          } else {
            handleLogout();
          }
        })
        .catch(() => {
          // If network error, we can't verify, but let's trust local for now
          setUser(parsedUser);
        });
    }
  }, [token]);

  useEffect(() => {
    if (user) {
      const newSocket = io();
      newSocket.emit('join_user', user.id);
      setSocket(newSocket);
      return () => {
        newSocket.close();
      };
    }
  }, [user]);

  const handleLogin = (userData: User, userToken: string) => {
    setUser(userData);
    setToken(userToken);
    localStorage.setItem('token', userToken);
    localStorage.setItem('user', JSON.stringify(userData));
  };

  const handleLogout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setView('dashboard');
    setActiveChat(null);
  };

  const openChat = (conn: Connection) => {
    setActiveChat(conn);
    setView('chat');
  };

  if (!token || !user) {
    return <Auth onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-neutral-50 font-sans text-neutral-900">
      <Navbar user={user} onLogout={handleLogout} onHome={() => setView('dashboard')} />
      
      <main className="max-w-7xl mx-auto px-4 py-8">
        {view === 'dashboard' ? (
          user.role === 'student' ? (
            <StudentDashboard user={user} onOpenChat={openChat} onLogout={handleLogout} />
          ) : (
            <MentorDashboard user={user} onOpenChat={openChat} onLogout={handleLogout} socket={socket} />
          )
        ) : (
          activeChat && (
            <ChatRoom 
              user={user} 
              connection={activeChat} 
              onBack={() => setView('dashboard')} 
              socket={socket}
            />
          )
        )}
      </main>
    </div>
  );
}
