import { GoogleGenAI, Type } from "@google/genai";
import { User, Message } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function analyzeMentorProfiles(linkedinUrl: string, githubUrl: string, cvUrl: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Analyze these professional profiles for a mentor:
      LinkedIn: ${linkedinUrl}
      GitHub: ${githubUrl}
      CV/Resume: ${cvUrl}
      
      Provide a 'Master Rating' from 1.0 to 5.0 based on their perceived expertise, industry experience, and technical contributions.
      Be objective and professional.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            rating: {
              type: Type.NUMBER,
              description: "The calculated master rating from 1.0 to 5.0",
            },
            reasoning: {
              type: Type.STRING,
              description: "Brief explanation for the rating",
            },
          },
          required: ["rating", "reasoning"],
        },
        tools: [{ urlContext: {} }]
      },
    });

    const result = JSON.parse(response.text || "{}");
    return {
      rating: result.rating || 1.0,
      reasoning: result.reasoning || "Analysis complete."
    };
  } catch (error) {
    console.error("Gemini analysis failed:", error);
    // Fallback to heuristic if Gemini fails
    let rating = 1.0;
    if (linkedinUrl.includes('linkedin.com')) rating += 1.5;
    if (githubUrl.includes('github.com')) rating += 1.5;
    return { rating, reasoning: "Heuristic fallback used due to analysis error." };
  }
}

export async function recommendMentors(studentBranch: string, studentSkills: string[], mentors: User[]) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are a career advisor. Recommend the best 3 mentors from the list for a student.
      Student Branch: ${studentBranch}
      Student Skills: ${studentSkills.join(", ")}
      
      Mentors List:
      ${JSON.stringify(mentors.map(m => ({ id: m.id, name: m.name, skills: m.skills, branch: m.branch, bio: m.bio })))}
      
      Provide the IDs of the recommended mentors and a short reason for each.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            recommendations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  mentorId: { type: Type.NUMBER },
                  reason: { type: Type.STRING }
                },
                required: ["mentorId", "reason"]
              }
            }
          },
          required: ["recommendations"]
        }
      }
    });

    const result = JSON.parse(response.text || "{}");
    return result.recommendations || [];
  } catch (error) {
    console.error("Gemini recommendation failed:", error);
    return [];
  }
}

export async function summarizeChat(messages: Message[]) {
  try {
    const chatHistory = messages.map(m => `${m.senderId === messages[0].senderId ? 'User 1' : 'User 2'}: ${m.text || '[Non-text message]'}`).join("\n");
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Summarize this mentorship chat history in 3 bullet points focusing on key advice given and next steps:
      
      ${chatHistory}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ["summary"]
        }
      }
    });

    const result = JSON.parse(response.text || "{}");
    return result.summary || [];
  } catch (error) {
    console.error("Gemini summary failed:", error);
    return ["Summary unavailable."];
  }
}

export async function getChatbotResponse(message: string, studentInfo: { branch: string, skills: string[] }) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are a helpful assistant for the Virtual Mentor Bridge platform. 
      You are talking to a student in the ${studentInfo.branch} branch with skills: ${studentInfo.skills.join(", ")}.
      
      Help them with:
      1. Career advice related to their branch.
      2. How to find the best mentors on the platform.
      3. General technical questions.
      
      Student's message: ${message}`,
      config: {
        systemInstruction: "Keep responses concise, encouraging, and professional. Use markdown for formatting.",
      }
    });

    return response.text || "I'm sorry, I couldn't process that request.";
  } catch (error) {
    console.error("Gemini chatbot failed:", error);
    return "I'm having a bit of trouble connecting right now. Please try again later!";
  }
}
