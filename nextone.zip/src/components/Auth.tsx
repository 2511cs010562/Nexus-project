import { useState, FormEvent } from 'react';
import { User, Role } from '../types';
import { Mail, Lock, User as UserIcon, ArrowRight, CheckCircle2, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { analyzeMentorProfiles } from '../services/geminiService';

interface AuthProps {
  onLogin: (user: User, token: string) => void;
}

export default function Auth({ onLogin }: AuthProps) {
  const [mode, setMode] = useState<'login' | 'signup' | 'otp' | 'verify'>('login');
  const [role, setRole] = useState<Role>('student');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    branch: 'CSE',
    otp: '',
    gender: 'male' as 'male' | 'female',
    linkedinUrl: '',
    githubUrl: '',
    cvUrl: ''
  });
  const [userId, setUserId] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (mode === 'signup') {
        const res = await fetch('/api/auth/signup', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...formData, role })
        });
        const data = await res.json();
        if (res.ok) {
          setUserId(data.userId);
          setMode('otp');
          if (data.debugOtp) {
            setFormData(prev => ({ ...prev, otp: data.debugOtp }));
            alert(`Demo Mode: OTP "${data.debugOtp}" has been auto-filled for you. (In production, this would be sent to your email)`);
          }
        } else {
          setError(data.error);
        }
      } else if (mode === 'login') {
        const res = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: formData.email, password: formData.password })
        });
        const data = await res.json();
        if (res.ok) {
          onLogin(data.user, data.token);
        } else {
          setError(data.error);
        }
      } else if (mode === 'otp') {
        const res = await fetch('/api/auth/verify-otp', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: formData.email, otp: formData.otp })
        });
        const data = await res.json();
        if (res.ok) {
          if (role === 'mentor') {
            setMode('verify');
          } else {
            setMode('login');
            alert('Email verified! Please login.');
          }
        } else {
          setError(data.error);
        }
      } else if (mode === 'verify') {
        // Call Gemini for analysis
        const analysis = await analyzeMentorProfiles(
          formData.linkedinUrl,
          formData.githubUrl,
          formData.cvUrl || 'https://example.com/cv.pdf'
        );

        const res = await fetch('/api/mentors/verify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            userId,
            linkedinUrl: formData.linkedinUrl,
            githubUrl: formData.githubUrl,
            cvUrl: formData.cvUrl || 'https://example.com/cv.pdf',
            rating: analysis.rating
          })
        });
        if (res.ok) {
          setMode('login');
          alert(`Verification submitted! Your AI Master Rating is ${analysis.rating.toFixed(1)}. Reasoning: ${analysis.reasoning}`);
        } else {
          const data = await res.json();
          setError(data.error);
        }
      }
    } catch (err) {
      setError('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-neutral-50 p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-white rounded-3xl shadow-xl shadow-neutral-200/50 border border-neutral-100 overflow-hidden"
      >
        <div className="p-8">
          <div className="flex justify-center mb-8">
            <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center text-white text-3xl font-bold">
              V
            </div>
          </div>

          <h2 className="text-2xl font-bold text-center mb-2">
            {mode === 'login' ? 'Welcome Back' : mode === 'signup' ? 'Create Account' : mode === 'otp' ? 'Verify Email' : 'Professional Verification'}
          </h2>
          <p className="text-neutral-500 text-center mb-8 text-sm">
            {mode === 'login' ? 'Login to connect with your mentors' : mode === 'signup' ? 'Join the bridge between students and masters' : mode === 'otp' ? 'Enter the 6-digit code sent to your email' : 'Provide your professional links to get your AI Master Rating'}
          </p>

          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-100 text-red-600 text-sm rounded-xl">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <AnimatePresence mode="wait">
              {mode === 'signup' && (
                <motion.div
                  key="signup-fields"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-4"
                >
                  <div className="flex gap-2 p-1 bg-neutral-100 rounded-xl mb-4">
                    <button
                      type="button"
                      onClick={() => setRole('student')}
                      className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all ${role === 'student' ? 'bg-white shadow-sm text-indigo-600' : 'text-neutral-500'}`}
                    >
                      Student
                    </button>
                    <button
                      type="button"
                      onClick={() => setRole('mentor')}
                      className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all ${role === 'mentor' ? 'bg-white shadow-sm text-indigo-600' : 'text-neutral-500'}`}
                    >
                      Mentor
                    </button>
                  </div>

                  <div className="relative">
                    <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" size={20} />
                    <input
                      type="text"
                      placeholder="Full Name"
                      required
                      className="w-full pl-10 pr-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
                      value={formData.name}
                      onChange={e => setFormData({ ...formData, name: e.target.value })}
                    />
                  </div>

                  <div className="relative">
                    <select
                      className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all appearance-none"
                      value={formData.branch}
                      onChange={e => setFormData({ ...formData, branch: e.target.value })}
                    >
                      <option value="CSE">Computer Science (CSE)</option>
                      <option value="ECE">Electronics (ECE)</option>
                      <option value="Civil">Civil Engineering</option>
                      <option value="Mechanical">Mechanical Engineering</option>
                    </select>
                  </div>

                  <div className="flex gap-2 p-1 bg-neutral-100 rounded-xl">
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, gender: 'male' })}
                      className={`flex-1 py-2 text-xs font-medium rounded-lg transition-all ${formData.gender === 'male' ? 'bg-white shadow-sm text-indigo-600' : 'text-neutral-500'}`}
                    >
                      Male
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, gender: 'female' })}
                      className={`flex-1 py-2 text-xs font-medium rounded-lg transition-all ${formData.gender === 'female' ? 'bg-white shadow-sm text-indigo-600' : 'text-neutral-500'}`}
                    >
                      Female
                    </button>
                  </div>
                </motion.div>
              )}
              {mode === 'verify' && (
                <motion.div
                  key="verify-fields"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-4"
                >
                  <div className="relative">
                    <input
                      type="url"
                      placeholder="LinkedIn Profile URL"
                      required
                      className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
                      value={formData.linkedinUrl}
                      onChange={e => setFormData({ ...formData, linkedinUrl: e.target.value })}
                    />
                  </div>
                  <div className="relative">
                    <input
                      type="url"
                      placeholder="GitHub Profile URL"
                      required
                      className="w-full px-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
                      value={formData.githubUrl}
                      onChange={e => setFormData({ ...formData, githubUrl: e.target.value })}
                    />
                  </div>
                  <div className="p-4 bg-indigo-50 border border-dashed border-indigo-200 rounded-xl text-center">
                    <p className="text-xs text-indigo-600 font-bold mb-1">CV / Resume Upload</p>
                    <p className="text-[10px] text-indigo-400">PDF format supported (Max 5MB)</p>
                    <input 
                      type="file" 
                      accept=".pdf" 
                      className="hidden" 
                      id="cv-upload" 
                      onChange={() => setFormData({...formData, cvUrl: 'https://example.com/cv.pdf'})}
                    />
                    <label htmlFor="cv-upload" className="mt-2 inline-block px-4 py-1.5 bg-white text-indigo-600 text-[10px] font-bold rounded-lg cursor-pointer hover:bg-indigo-50 transition-colors border border-indigo-100">
                      Choose File
                    </label>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {mode !== 'otp' && mode !== 'verify' ? (
              <>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" size={20} />
                  <input
                    type="email"
                    placeholder="Email Address"
                    required
                    className="w-full pl-10 pr-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
                    value={formData.email}
                    onChange={e => setFormData({ ...formData, email: e.target.value })}
                  />
                </div>

                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" size={20} />
                  <input
                    type="password"
                    placeholder="Password"
                    required
                    className="w-full pl-10 pr-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
                    value={formData.password}
                    onChange={e => setFormData({ ...formData, password: e.target.value })}
                  />
                </div>
              </>
            ) : (
              <div className="relative">
                <CheckCircle2 className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" size={20} />
                <input
                  type="text"
                  placeholder="6-Digit OTP"
                  required
                  maxLength={6}
                  className="w-full pl-10 pr-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all tracking-[0.5em] text-center font-bold"
                  value={formData.otp}
                  onChange={e => setFormData({ ...formData, otp: e.target.value })}
                />
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-lg shadow-indigo-200 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? (
                <>
                  <Sparkles className="animate-spin" size={20} />
                  {mode === 'verify' ? 'AI Analyzing Profiles...' : 'Processing...'}
                </>
              ) : (
                <>
                  {mode === 'login' ? 'Login' : mode === 'signup' ? 'Sign Up' : mode === 'otp' ? 'Verify' : 'Submit for AI Analysis'}
                  <ArrowRight size={20} />
                </>
              )}
            </button>
          </form>

          <div className="mt-8 text-center">
            <button
              onClick={() => setMode(mode === 'login' ? 'signup' : 'login')}
              className="text-sm text-neutral-500 hover:text-indigo-600 font-medium transition-colors"
            >
              {mode === 'login' ? "Don't have an account? Sign Up" : "Already have an account? Login"}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
