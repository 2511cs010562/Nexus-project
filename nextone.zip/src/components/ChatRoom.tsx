import { useState, useEffect, useRef } from 'react';
import { User, Connection, Message } from '../types';
import { Send, Mic, Video, FileText, ChevronLeft, Paperclip, Play, Square, Download, VideoIcon, Sparkles, BrainCircuit, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Socket } from 'socket.io-client';
import { useReactMediaRecorder } from 'react-media-recorder';
import { summarizeChat } from '../services/geminiService';

interface ChatRoomProps {
  user: User;
  connection: Connection;
  onBack: () => void;
  socket: Socket | null;
}

export default function ChatRoom({ user, connection, onBack, socket }: ChatRoomProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [summary, setSummary] = useState<string[]>([]);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [playingId, setPlayingId] = useState<number | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const {
    status,
    startRecording,
    stopRecording,
    mediaBlobUrl,
    clearBlobUrl
  } = useReactMediaRecorder({ 
    audio: true
  });

  useEffect(() => {
    fetchMessages();
    if (socket) {
      socket.emit('join_room', connection.roomId);
      socket.on('message', (msg: Message) => {
        setMessages(prev => [...prev, msg]);
      });
    }
    return () => {
      socket?.off('message');
    };
  }, [connection.roomId, socket]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const fetchMessages = async () => {
    try {
      const res = await fetch(`/api/messages/${connection.roomId}`);
      if (!res.ok) throw new Error('Failed to fetch messages');
      const data = await res.json();
      setMessages(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error(err);
      setMessages([]);
    }
  };

  const sendMessage = async (type: Message['type'] = 'text', content?: string) => {
    if (type === 'text' && !inputText.trim()) return;
    
    const messageData = {
      roomId: connection.roomId,
      senderId: user.id,
      text: type === 'text' ? inputText : content,
      type,
      voiceUrl: type === 'voice' ? content : undefined
    };

    try {
      await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(messageData)
      });
      setInputText('');
      if (type === 'voice') clearBlobUrl();
    } catch (err) {
      console.error(err);
    }
  };

  const handleVoiceSend = async () => {
    if (mediaBlobUrl) {
      try {
        const response = await fetch(mediaBlobUrl);
        const blob = await response.blob();
        const reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onloadend = () => {
          const base64data = reader.result as string;
          console.log(`[VOICE] Sending base64 audio, length: ${base64data.length}`);
          sendMessage('voice', base64data);
        };
      } catch (err) {
        console.error("Failed to process voice note:", err);
      }
    }
  };

  const handleSummarize = async () => {
    if (messages.length < 3) return;
    setIsSummarizing(true);
    try {
      const s = await summarizeChat(messages);
      setSummary(s);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSummarizing(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto h-[calc(100vh-160px)] flex flex-col bg-white rounded-[3rem] shadow-xl border border-neutral-200 overflow-hidden">
      {/* Header */}
      <div className="p-6 border-b border-neutral-100 flex items-center justify-between bg-white/80 backdrop-blur-md sticky top-0 z-10">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-2 text-neutral-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-colors"
          >
            <ChevronLeft size={24} />
          </button>
          <div className="flex items-center gap-3">
            {connection.otherProfilePic ? (
              <img 
                src={connection.otherProfilePic} 
                alt={connection.otherName} 
                className="w-12 h-12 rounded-2xl object-cover"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-12 h-12 bg-indigo-100 rounded-2xl flex items-center justify-center text-indigo-600 font-bold text-xl">
                {(connection.otherName || '?')[0]}
              </div>
            )}
            <div>
              <h3 className="font-bold text-lg leading-tight">{connection.otherName}</h3>
              <p className="text-xs text-neutral-500 flex items-center gap-1">
                <span className="w-2 h-2 bg-emerald-500 rounded-full"></span> Online
              </p>
            </div>
          </div>
        </div>
        
          <div className="flex gap-2">
            <button 
              onClick={() => {
                const roomName = `MentorBridge-${connection.roomId}`;
                const jitsiUrl = `https://meet.jit.si/${roomName}`;
                sendMessage('video_call', jitsiUrl);
                window.open(jitsiUrl, '_blank');
              }}
              className="p-2.5 text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition-colors flex items-center gap-2 text-xs font-bold shadow-lg shadow-indigo-100"
              title="Start Video Call"
            >
              <VideoIcon size={18} /> <span className="hidden sm:inline">Video Call</span>
            </button>
            <button 
              onClick={handleSummarize}
              disabled={isSummarizing || messages.length < 3}
              className="p-2.5 text-indigo-600 bg-white border border-indigo-100 hover:bg-indigo-50 rounded-xl transition-colors flex items-center gap-2 text-xs font-bold disabled:opacity-50"
              title="AI Chat Summary"
            >
              <BrainCircuit size={18} /> <span className="hidden sm:inline">AI Summary</span>
            </button>
            {user.role === 'mentor' && (
              <>
                <button 
                  onClick={() => sendMessage('video', 'https://www.youtube.com/watch?v=8pDquaoE_6s')}
                  className="p-2.5 text-indigo-600 bg-indigo-50 hover:bg-indigo-100 rounded-xl transition-colors flex items-center gap-2 text-xs font-bold"
                  title="Send Frontend Masterclass"
                >
                  <Video size={18} /> <span className="hidden sm:inline">Video</span>
                </button>
                <button 
                  onClick={() => sendMessage('roadmap', 'https://roadmap.sh/frontend')}
                  className="p-2.5 text-emerald-600 bg-emerald-50 hover:bg-emerald-100 rounded-xl transition-colors flex items-center gap-2 text-xs font-bold"
                  title="Send Roadmap"
                >
                  <FileText size={18} /> <span className="hidden sm:inline">Roadmap</span>
                </button>
              </>
            )}
          </div>
        </div>

      {/* Messages Area */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-8 space-y-6 bg-neutral-50/50"
      >
        <AnimatePresence>
          {summary.length > 0 && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mb-8"
            >
              <div className="bg-indigo-600 rounded-3xl p-6 text-white shadow-xl shadow-indigo-100 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-8 opacity-10">
                  <BrainCircuit size={120} />
                </div>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Sparkles size={20} />
                    <h4 className="font-bold">AI Mentorship Summary</h4>
                  </div>
                  <button onClick={() => setSummary([])} className="text-indigo-200 hover:text-white transition-colors">
                    <X size={20} />
                  </button>
                </div>
                <ul className="space-y-2">
                  {summary.map((point, i) => (
                    <li key={i} className="text-sm flex gap-2">
                      <span className="text-indigo-300">•</span>
                      {point}
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {messages.map((msg, idx) => {
          const isMe = msg.senderId === user.id;
          return (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[80%] flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                <div className={`p-4 rounded-2xl shadow-sm ${
                  isMe 
                    ? 'bg-indigo-600 text-white rounded-tr-none' 
                    : 'bg-white text-neutral-800 border border-neutral-100 rounded-tl-none'
                }`}>
                  {msg.type === 'text' && <p className="text-sm leading-relaxed">{msg.text}</p>}
                  
                  {msg.type === 'voice' && (
                    <div className="flex items-center gap-3 min-w-[220px] py-1">
                      <div className="flex flex-col gap-1">
                        <button 
                          onClick={() => {
                            if (!msg.voiceUrl) return;
                            if (msg.voiceUrl.startsWith('blob:')) {
                              alert("This is a legacy voice note from a previous session and is no longer playable. New voice notes will work correctly.");
                              return;
                            }
                            
                            const audioId = `audio-${idx}`;
                            const audioElement = document.getElementById(audioId) as HTMLAudioElement;
                            
                            if (playingId === idx) {
                              audioElement.pause();
                              setPlayingId(null);
                            } else {
                              audioElement.play().catch(e => {
                                console.error("Playback failed:", e);
                                alert("Playback failed. Please ensure your browser allows audio playback.");
                              });
                              setPlayingId(idx);
                            }
                          }}
                          className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                            isMe ? 'bg-white/20 hover:bg-white/30' : 'bg-indigo-50 text-indigo-600 hover:bg-indigo-100'
                          } ${playingId === idx ? 'ring-2 ring-white animate-pulse' : ''}`}
                        >
                          {playingId === idx ? <Square size={18} className="fill-current" /> : <Play size={18} className="fill-current" />}
                        </button>
                        <audio 
                          id={`audio-${idx}`} 
                          src={msg.voiceUrl?.startsWith('blob:') && !isMe ? '' : msg.voiceUrl} 
                          onEnded={() => setPlayingId(null)}
                          onError={(e) => {
                            setPlayingId(null);
                            const target = e.target as HTMLAudioElement;
                            if (msg.voiceUrl?.startsWith('blob:')) {
                              // Ignore errors for legacy blobs as we already handle them in onClick
                              return;
                            }
                            console.error("Audio error on element:", target.error);
                          }}
                          className="hidden"
                          preload="none"
                        />
                      </div>
                      <div className="flex-1">
                        <div className="h-1.5 bg-current opacity-20 rounded-full overflow-hidden">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: '100%' }}
                            transition={{ duration: 2, ease: "linear" }}
                            className="h-full bg-current"
                          />
                        </div>
                        <div className="flex justify-between mt-1">
                          <span className="text-[10px] font-bold opacity-70 uppercase tracking-tighter">Voice Note</span>
                          <span className="text-[10px] font-bold opacity-70">0:02</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {msg.type === 'video_call' && (
                    <div className="space-y-3">
                      <div className="flex items-center gap-3 p-3 bg-indigo-500/10 rounded-xl border border-indigo-500/20">
                        <div className="w-10 h-10 bg-indigo-600 text-white rounded-full flex items-center justify-center">
                          <VideoIcon size={20} />
                        </div>
                        <div className="flex-1">
                          <p className="text-xs font-bold">Live Video Session</p>
                          <p className="text-[10px] opacity-70">Click to join the meeting</p>
                        </div>
                      </div>
                      <button 
                        onClick={() => window.open(msg.text, '_blank')}
                        className={`w-full py-2 rounded-lg text-xs font-bold transition-colors ${
                          isMe ? 'bg-white text-indigo-600' : 'bg-indigo-600 text-white'
                        }`}
                      >
                        Join Meeting
                      </button>
                    </div>
                  )}

                  {msg.type === 'video' && (
                    <div className="space-y-3">
                      <div className="aspect-video bg-neutral-900 rounded-lg flex items-center justify-center overflow-hidden relative group">
                        <img src="https://picsum.photos/seed/video/400/225" alt="Video Preview" className="w-full h-full object-cover opacity-60" />
                        <Play size={32} className="absolute text-white group-hover:scale-110 transition-transform" />
                      </div>
                      <a href={msg.text} target="_blank" rel="noreferrer" className="text-xs font-bold underline block truncate">
                        Watch Master Resource
                      </a>
                    </div>
                  )}

                  {msg.type === 'roadmap' && (
                    <div className="flex items-center gap-4 p-2 bg-black/5 rounded-xl">
                      <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center text-emerald-600">
                        <FileText size={24} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold truncate">Master Roadmap.pdf</p>
                        <a href={msg.text} target="_blank" rel="noreferrer" className="text-[10px] opacity-70 hover:underline">Download Resource</a>
                      </div>
                      <Download size={16} className="opacity-50" />
                    </div>
                  )}
                </div>
                <span className="text-[10px] text-neutral-400 mt-1 font-medium">
                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Input Area */}
      <div className="p-6 bg-white border-t border-neutral-100">
        <AnimatePresence>
          {mediaBlobUrl && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="mb-4 p-4 bg-indigo-50 rounded-2xl flex items-center justify-between border border-indigo-100"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-indigo-600 text-white rounded-full flex items-center justify-center">
                  <Mic size={16} />
                </div>
                <span className="text-xs font-bold text-indigo-600">Voice Note Ready</span>
              </div>
              <div className="flex gap-2">
                <button onClick={clearBlobUrl} className="px-4 py-2 text-xs font-bold text-neutral-500 hover:text-red-600 transition-colors">Discard</button>
                <button onClick={handleVoiceSend} className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 transition-colors">Send Voice</button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex items-center gap-3">
          <input 
            type="file" 
            id="file-upload" 
            className="hidden" 
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                sendMessage('text', `Shared a file: ${file.name}`);
              }
            }}
          />
          <label 
            htmlFor="file-upload"
            className="p-3 text-neutral-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-colors cursor-pointer"
          >
            <Paperclip size={20} />
          </label>
          
          <div className="flex-1 relative">
            <input 
              type="text" 
              placeholder="Type your message..."
              className="w-full pl-4 pr-12 py-3.5 bg-neutral-50 border border-neutral-200 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
              value={inputText}
              onChange={e => setInputText(e.target.value)}
              onKeyPress={e => e.key === 'Enter' && sendMessage()}
            />
            <button 
              onClick={() => {
                if (status === 'recording') {
                  stopRecording();
                  setIsRecording(false);
                } else {
                  startRecording();
                  setIsRecording(true);
                }
              }}
              className={`absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-lg transition-all ${
                isRecording ? 'bg-red-500 text-white animate-pulse' : 'text-neutral-400 hover:text-indigo-600 hover:bg-indigo-50'
              }`}
            >
              {isRecording ? <Square size={18} /> : <Mic size={18} />}
            </button>
          </div>

          <button 
            onClick={() => sendMessage()}
            disabled={!inputText.trim()}
            className="p-3.5 bg-indigo-600 text-white rounded-2xl shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all disabled:opacity-50 disabled:shadow-none"
          >
            <Send size={20} />
          </button>
        </div>
      </div>
    </div>
  );
}
