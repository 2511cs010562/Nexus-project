import { useState, useEffect } from 'react';
import { User, Connection, PendingRequest } from '../types';
import { Bell, Check, X, MessageSquare, Star, Plus, Trash2, Linkedin, Github, Sparkles } from 'lucide-react';
import { Socket } from 'socket.io-client';
import { motion, AnimatePresence } from 'motion/react';

interface MentorDashboardProps {
  user: User;
  onOpenChat: (conn: Connection) => void;
  onLogout: () => void;
  socket: Socket | null;
}

export default function MentorDashboard({ user, onOpenChat, onLogout, socket }: MentorDashboardProps) {
  const [pendingRequests, setPendingRequests] = useState<PendingRequest[]>([]);
  const [activeConnections, setActiveConnections] = useState<Connection[]>([]);
  const [skills, setSkills] = useState<string[]>(user.skills || []);
  const [newSkill, setNewSkill] = useState('');
  const [showNotification, setShowNotification] = useState(false);

  useEffect(() => {
    fetchPendingRequests();
    fetchActiveConnections();

    if (socket) {
      socket.on('new_request', () => {
        fetchPendingRequests();
        setShowNotification(true);
        setTimeout(() => setShowNotification(false), 5000);
      });
    }

    return () => {
      if (socket) socket.off('new_request');
    };
  }, [socket]);

  const fetchPendingRequests = async () => {
    if (!user?.id) return;
    try {
      const res = await fetch(`/api/connections/pending/${user.id}`);
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || 'Failed to fetch pending requests');
      }
      const data = await res.json();
      setPendingRequests(Array.isArray(data) ? data : []);
    } catch (err: any) {
      if (err.message.includes('User not found')) {
        onLogout();
      } else {
        console.error(err);
      }
      setPendingRequests([]);
    }
  };

  const fetchActiveConnections = async () => {
    if (!user?.id) return;
    try {
      const res = await fetch(`/api/connections/active/${user.id}`);
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || `Failed to fetch connections (Status: ${res.status})`);
      }
      const data = await res.json();
      setActiveConnections(Array.isArray(data) ? data : []);
    } catch (err: any) {
      if (err.message.includes('User not found')) {
        onLogout();
      } else {
        console.error("Connection fetch error:", err);
      }
      setActiveConnections([]);
    }
  };

  const handleResponse = async (requestId: number, status: 'accepted' | 'rejected') => {
    await fetch('/api/connections/respond', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ connectionId: requestId, status })
    });
    fetchPendingRequests();
    fetchActiveConnections();
  };

  const handleAddSkill = async () => {
    if (!newSkill.trim()) return;
    const updatedSkills = [...skills, newSkill.trim()];
    const res = await fetch('/api/users/update-skills', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: user.id, skills: updatedSkills })
    });
    if (res.ok) {
      setSkills(updatedSkills);
      setNewSkill('');
    }
  };

  const handleRemoveSkill = async (skillToRemove: string) => {
    const updatedSkills = skills.filter(s => s !== skillToRemove);
    const res = await fetch('/api/users/update-skills', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: user.id, skills: updatedSkills })
    });
    if (res.ok) {
      setSkills(updatedSkills);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* Left Column: Profile & Skills */}
      <div className="lg:col-span-4 space-y-6">
        <div className="bg-white p-8 rounded-[2.5rem] border border-neutral-200 shadow-sm text-center">
          <div className="relative inline-block mb-4">
            {user.profilePic ? (
              <img 
                src={user.profilePic} 
                alt={user.name} 
                className="w-24 h-24 rounded-full object-cover border-4 border-white shadow-lg"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-24 h-24 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 text-3xl font-bold border-4 border-white shadow-lg">
                {(user.name || '?')[0]}
              </div>
            )}
            <div className="absolute -bottom-1 -right-1 bg-yellow-400 text-white p-1.5 rounded-full border-2 border-white shadow-sm">
              <Star size={14} className="fill-white" />
            </div>
          </div>
          <h2 className="text-xl font-bold mb-1">{user.name}</h2>
          <p className="text-neutral-500 text-sm mb-4">{user.branch} Mentor</p>
          <div className="flex flex-col items-center gap-2 mb-4">
            <div className="flex items-center justify-center gap-1 text-yellow-500 font-bold text-sm">
              <Star size={16} className="fill-current" />
              <span>{(user.rating || 0).toFixed(1)} User Rating</span>
            </div>
            <div className="flex items-center justify-center gap-1 text-indigo-600 font-bold text-sm bg-indigo-50 px-3 py-1 rounded-full">
              <Sparkles size={16} className="text-indigo-500" />
              <span>{(user.systemRating || 0).toFixed(1)} AI Master Rating</span>
            </div>
          </div>
          
          <div className="flex justify-center gap-4 pt-4 border-t border-neutral-100">
            {user.linkedinUrl && (
              <a 
                href={user.linkedinUrl} 
                target="_blank" 
                rel="noreferrer"
                className="p-2 bg-indigo-50 text-indigo-600 rounded-xl hover:bg-indigo-600 hover:text-white transition-all"
                title="Your LinkedIn Profile"
              >
                <Linkedin size={20} />
              </a>
            )}
            {user.githubUrl && (
              <a 
                href={user.githubUrl} 
                target="_blank" 
                rel="noreferrer"
                className="p-2 bg-neutral-50 text-neutral-600 rounded-xl hover:bg-neutral-600 hover:text-white transition-all"
                title="Your GitHub Profile"
              >
                <Github size={20} />
              </a>
            )}
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-neutral-200 shadow-sm">
          <h3 className="font-bold mb-4 flex items-center gap-2">
            <Plus size={18} className="text-indigo-600" />
            Master Skills
          </h3>
          <div className="flex flex-wrap gap-2 mb-6">
            <AnimatePresence>
              {skills.map(skill => (
                <motion.span 
                  key={skill}
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.8, opacity: 0 }}
                  className="px-3 py-1 bg-indigo-50 text-indigo-600 text-xs font-bold rounded-full flex items-center gap-2 group"
                >
                  {skill}
                  <button onClick={() => handleRemoveSkill(skill)} className="text-indigo-300 hover:text-red-500 transition-colors">
                    <Trash2 size={12} />
                  </button>
                </motion.span>
              ))}
            </AnimatePresence>
          </div>
          <div className="flex gap-2">
            <input 
              type="text" 
              placeholder="Add skill..."
              className="flex-1 p-2 bg-neutral-50 border border-neutral-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-indigo-500"
              value={newSkill}
              onChange={e => setNewSkill(e.target.value)}
              onKeyPress={e => e.key === 'Enter' && handleAddSkill()}
            />
            <button 
              onClick={handleAddSkill}
              className="p-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors"
            >
              <Plus size={20} />
            </button>
          </div>
        </div>
      </div>

      {/* Right Column: Requests & Chats */}
      <div className="lg:col-span-8 space-y-8">
        {/* Pending Requests */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold flex items-center gap-2">
              <Bell size={20} className="text-indigo-600" />
              Student Requests
              {pendingRequests.length > 0 && (
                <span className="bg-red-500 text-white text-[10px] px-1.5 py-0.5 rounded-full ml-1">
                  {pendingRequests.length}
                </span>
              )}
            </h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <AnimatePresence mode="popLayout">
              {pendingRequests.length === 0 ? (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="col-span-full p-8 bg-white rounded-3xl border border-dashed border-neutral-200 text-center text-neutral-400 italic"
                >
                  No pending requests at the moment.
                </motion.div>
              ) : (
                pendingRequests.map(req => (
                  <motion.div 
                    key={req.id}
                    layout
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="bg-white p-5 rounded-3xl border border-neutral-200 shadow-sm flex items-center justify-between group hover:border-indigo-200 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      {req.studentProfilePic ? (
                        <img 
                          src={req.studentProfilePic} 
                          alt={req.studentName} 
                          className="w-12 h-12 rounded-2xl object-cover"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600 font-bold text-lg">
                          {(req.studentName || '?')[0]}
                        </div>
                      )}
                      <div>
                        <p className="font-bold text-sm">{req.studentName}</p>
                        <p className="text-xs text-neutral-500">{req.studentBranch}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => handleResponse(req.id, 'accepted')}
                        className="p-2 bg-emerald-50 text-emerald-600 rounded-xl hover:bg-emerald-600 hover:text-white transition-all"
                        title="Accept"
                      >
                        <Check size={18} />
                      </button>
                      <button 
                        onClick={() => handleResponse(req.id, 'rejected')}
                        className="p-2 bg-red-50 text-red-600 rounded-xl hover:bg-red-600 hover:text-white transition-all"
                        title="Reject"
                      >
                        <X size={18} />
                      </button>
                    </div>
                  </motion.div>
                ))
              )}
            </AnimatePresence>
          </div>
        </section>

        {/* Active Chats */}
        <section>
          <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
            <MessageSquare size={20} className="text-indigo-600" />
            Active Mentorships
          </h3>
          <div className="bg-white rounded-[2rem] border border-neutral-200 shadow-sm overflow-hidden">
            {activeConnections.length === 0 ? (
              <div className="p-12 text-center text-neutral-400 italic">
                No active mentorships yet. Accept a request to start bridging!
              </div>
            ) : (
              <div className="divide-y divide-neutral-100">
                {activeConnections.map(conn => (
                  <button
                    key={conn.id}
                    onClick={() => onOpenChat(conn)}
                    className="w-full p-6 flex items-center justify-between hover:bg-neutral-50 transition-colors group"
                  >
                    <div className="flex items-center gap-4">
                      {conn.otherProfilePic ? (
                        <img 
                          src={conn.otherProfilePic} 
                          alt={conn.otherName} 
                          className="w-12 h-12 rounded-2xl object-cover"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="w-12 h-12 bg-neutral-100 rounded-2xl flex items-center justify-center text-neutral-600 font-bold">
                          {(conn.otherName || '?')[0]}
                        </div>
                      )}
                      <div className="text-left">
                        <p className="font-bold">{conn.otherName}</p>
                        <p className="text-xs text-neutral-500">Student • Active Session</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-indigo-600 font-bold text-sm opacity-0 group-hover:opacity-100 transition-opacity">
                      Open Chat
                      <MessageSquare size={16} />
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </section>
      </div>

      {/* Real-time Notification Toast */}
      <AnimatePresence>
        {showNotification && (
          <motion.div 
            initial={{ opacity: 0, y: 50, x: '-50%' }}
            animate={{ opacity: 1, y: 0, x: '-50%' }}
            exit={{ opacity: 0, y: 50, x: '-50%' }}
            className="fixed bottom-8 left-1/2 bg-indigo-600 text-white px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 z-[100] font-bold"
          >
            <Bell size={20} className="animate-bounce" />
            New Student Request Received!
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
