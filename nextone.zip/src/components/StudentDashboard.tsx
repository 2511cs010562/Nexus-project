import { useState, useEffect } from 'react';
import { User, Connection } from '../types';
import TinderCard from 'react-tinder-card';
import { Filter, Star, MapPin, Briefcase, MessageSquare, ChevronRight, X, Heart, Linkedin, Github, Sparkles, BrainCircuit } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { recommendMentors } from '../services/geminiService';
import StudentChatbot from './StudentChatbot';

interface StudentDashboardProps {
  user: User;
  onOpenChat: (conn: Connection) => void;
  onLogout: () => void;
}

export default function StudentDashboard({ user, onOpenChat, onLogout }: StudentDashboardProps) {
  const [mentors, setMentors] = useState<User[]>([]);
  const [activeConnections, setActiveConnections] = useState<Connection[]>([]);
  const [filters, setFilters] = useState({
    branch: '',
    skill: ''
  });
  const [loading, setLoading] = useState(true);
  const [aiRecommendations, setAiRecommendations] = useState<{ mentorId: number, reason: string }[]>([]);
  const [isAiLoading, setIsAiLoading] = useState(false);

  useEffect(() => {
    fetchMentors();
    fetchActiveConnections();
  }, []);

  const fetchMentors = async () => {
    if (!user?.id) return;
    try {
      const res = await fetch(`/api/mentors?studentId=${user.id}`);
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || 'Failed to fetch mentors');
      }
      const data = await res.json();
      setMentors(Array.isArray(data) ? data : []);
    } catch (err: any) {
      if (err.message.includes('User not found')) {
        onLogout();
      } else {
        console.error(err);
      }
      setMentors([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchActiveConnections = async () => {
    if (!user?.id) return;
    try {
      const res = await fetch(`/api/connections/active/${user.id}`);
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || `Failed to fetch connections (Status: ${res.status})`);
      }
      const data = await res.json();
      setActiveConnections(Array.isArray(data) ? data : []);
    } catch (err: any) {
      if (err.message.includes('User not found')) {
        onLogout();
      } else {
        console.error("Connection fetch error:", err);
      }
      setActiveConnections([]);
    }
  };

  const onSwipe = async (direction: string, mentorId: number) => {
    // Remove from local state immediately to prevent reappearing
    setMentors(prev => prev.filter(m => m.id !== mentorId));

    try {
      await fetch('/api/swipes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ studentId: user.id, mentorId, direction })
      });
    } catch (err) {
      console.error(err);
    }
  };

  const filteredMentors = mentors.filter(m => {
    // If no filter selected, show nothing
    if (!filters.branch && !filters.skill) return false;

    const branchMatch = !filters.branch || m.branch === filters.branch;
    const skillMatch = !filters.skill || (m.skills && m.skills.includes(filters.skill));
    // Also filter out mentors already connected
    const alreadyConnected = activeConnections.some(c => c.otherId === m.id);
    return branchMatch && skillMatch && !alreadyConnected;
  });

  const allSkills = Array.from(new Set(mentors.flatMap(m => m.skills)));

  const handleAiRecommend = async () => {
    setIsAiLoading(true);
    try {
      const recs = await recommendMentors(user.branch, user.skills || [], mentors);
      setAiRecommendations(recs);
    } catch (err) {
      console.error(err);
    } finally {
      setIsAiLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* Sidebar Filters */}
      <div className="lg:col-span-3 space-y-6">
        <div className="bg-white p-6 rounded-3xl border border-neutral-200 shadow-sm">
          <div className="flex items-center gap-2 mb-6 text-indigo-600">
            <Filter size={20} />
            <h3 className="font-bold">Discovery Filters</h3>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="text-xs font-bold text-neutral-400 uppercase tracking-wider mb-2 block">Branch</label>
              <select 
                className="w-full p-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                value={filters.branch}
                onChange={e => setFilters({ ...filters, branch: e.target.value })}
              >
                <option value="">Select Branch</option>
                <option value="CSE">Computer Science</option>
                <option value="ECE">Electronics</option>
                <option value="Civil">Civil</option>
                <option value="Mechanical">Mechanical</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-neutral-400 uppercase tracking-wider mb-2 block">Skill</label>
              <select 
                className="w-full p-3 bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                value={filters.skill}
                onChange={e => setFilters({ ...filters, skill: e.target.value })}
              >
                <option value="">Select Skill</option>
                {allSkills.map(skill => (
                  <option key={skill} value={skill}>{skill}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-neutral-200 shadow-sm">
          <div className="flex items-center gap-2 mb-6 text-indigo-600">
            <MessageSquare size={20} />
            <h3 className="font-bold">Active Mentors</h3>
          </div>
          <div className="space-y-3">
            {activeConnections.length === 0 ? (
              <p className="text-sm text-neutral-400 text-center py-4 italic">No active connections yet. Swipe right to start!</p>
            ) : (
              activeConnections.map(conn => (
                <button
                  key={conn.id}
                  onClick={() => onOpenChat(conn)}
                  className="w-full flex items-center gap-3 p-3 hover:bg-neutral-50 rounded-2xl transition-colors group text-left"
                >
                  {conn.otherProfilePic ? (
                    <img 
                      src={conn.otherProfilePic} 
                      alt={conn.otherName} 
                      className="w-10 h-10 rounded-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 font-bold">
                      {(conn.otherName || '?')[0]}
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold truncate">{conn.otherName}</p>
                    <p className="text-xs text-neutral-500">Active Chat</p>
                  </div>
                  <ChevronRight size={16} className="text-neutral-300 group-hover:text-indigo-600 transition-colors" />
                </button>
              ))
            )}
          </div>
        </div>

        <div className="bg-indigo-600 p-6 rounded-3xl text-white shadow-lg shadow-indigo-200">
          <div className="flex items-center gap-2 mb-4">
            <BrainCircuit size={20} />
            <h3 className="font-bold">AI Matchmaker</h3>
          </div>
          <p className="text-xs text-indigo-100 mb-4 leading-relaxed">
            Let Gemini analyze your profile and find the perfect masters for your career bridge.
          </p>
          <button 
            onClick={handleAiRecommend}
            disabled={isAiLoading || mentors.length === 0}
            className="w-full py-2.5 bg-white text-indigo-600 rounded-xl font-bold text-xs hover:bg-indigo-50 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {isAiLoading ? (
              <Sparkles className="animate-spin" size={16} />
            ) : (
              <Sparkles size={16} />
            )}
            {isAiLoading ? 'Analyzing...' : 'Get AI Recommendations'}
          </button>

          {aiRecommendations.length > 0 && (
            <div className="mt-4 space-y-3">
              {aiRecommendations.map(rec => {
                const mentor = mentors.find(m => m.id === rec.mentorId);
                if (!mentor) return null;
                return (
                  <div key={rec.mentorId} className="p-3 bg-white/10 rounded-xl border border-white/20">
                    <p className="text-[10px] font-bold text-white mb-1">{mentor.name}</p>
                    <p className="text-[9px] text-indigo-100 leading-tight">{rec.reason}</p>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Main Swipe Area */}
      <div className="lg:col-span-9">
        <div className="relative h-[600px] flex items-center justify-center overflow-hidden">
          {loading ? (
            <div className="flex flex-col items-center gap-4">
              <div className="w-12 h-12 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
              <p className="text-neutral-500 font-medium">Finding masters for you...</p>
            </div>
          ) : filteredMentors.length > 0 ? (
            <div className="relative w-full max-w-sm h-full">
              {filteredMentors.map((mentor) => (
                <TinderCard
                  key={mentor.id}
                  className="absolute inset-0"
                  onSwipe={(dir) => onSwipe(dir, mentor.id)}
                  preventSwipe={['up', 'down']}
                >
                  <div className="w-full h-full bg-white rounded-[2.5rem] shadow-2xl shadow-neutral-200 border border-neutral-100 overflow-hidden flex flex-col cursor-grab active:cursor-grabbing">
                    <div className="relative h-2/3">
                      <img 
                        src={mentor.profilePic || `https://picsum.photos/seed/${mentor.id}/400/600`} 
                        alt={mentor.name} 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                      <div className="absolute bottom-6 left-6 right-6 text-white">
                        <div className="flex items-center gap-2 mb-1">
                          <h2 className="text-3xl font-bold">{mentor.name}</h2>
                          <div className="flex flex-col gap-1">
                            <div className="flex items-center gap-1 bg-indigo-600/40 backdrop-blur-md px-2 py-0.5 rounded-lg text-[10px] font-bold text-white border border-indigo-400/30">
                              <Sparkles size={10} className="text-indigo-300" />
                              AI Master: {(mentor.systemRating || 0).toFixed(1)}
                            </div>
                            <div className="flex items-center gap-1 bg-white/20 backdrop-blur-md px-2 py-0.5 rounded-lg text-[10px] font-bold text-white">
                              <Star size={10} className="fill-yellow-400 text-yellow-400" />
                              Users: {(mentor.rating || 0).toFixed(1)}
                            </div>
                          </div>
                          {mentor.systemRating && mentor.systemRating > 2 && (
                            <div className="bg-indigo-500 text-white px-2 py-0.5 rounded-lg text-[10px] font-bold uppercase tracking-wider">
                              Verified
                            </div>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-white/80 text-sm">
                          <MapPin size={14} />
                          {mentor.branch}
                        </div>
                        <div className="flex gap-3 mt-3">
                          {mentor.linkedinUrl && (
                            <a 
                              href={mentor.linkedinUrl} 
                              target="_blank" 
                              rel="noreferrer"
                              onClick={(e) => e.stopPropagation()}
                              className="p-1.5 bg-white/10 backdrop-blur-md rounded-lg hover:bg-white/20 transition-colors"
                              title="LinkedIn Profile"
                            >
                              <Linkedin size={16} className="text-white" />
                            </a>
                          )}
                          {mentor.githubUrl && (
                            <a 
                              href={mentor.githubUrl} 
                              target="_blank" 
                              rel="noreferrer"
                              onClick={(e) => e.stopPropagation()}
                              className="p-1.5 bg-white/10 backdrop-blur-md rounded-lg hover:bg-white/20 transition-colors"
                              title="GitHub Profile"
                            >
                              <Github size={16} className="text-white" />
                            </a>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="p-6 flex-1 flex flex-col">
                      <div className="flex flex-wrap gap-2 mb-4">
                        {mentor.skills.map(skill => (
                          <span key={skill} className="px-3 py-1 bg-indigo-50 text-indigo-600 text-xs font-bold rounded-full">
                            {skill}
                          </span>
                        ))}
                      </div>
                      <p className="text-neutral-600 text-sm line-clamp-3 italic">
                        "{mentor.bio || 'Passionate mentor ready to help you bridge the gap between learning and industry excellence.'}"
                      </p>
                      
                      <div className="mt-auto flex justify-center gap-8 pt-4">
                        <button 
                          onClick={() => onSwipe('left', mentor.id)}
                          className="flex flex-col items-center gap-1 group/btn"
                        >
                          <div className="w-12 h-12 rounded-full border-2 border-red-100 flex items-center justify-center text-red-500 bg-red-50 group-hover/btn:bg-red-500 group-hover/btn:text-white transition-all">
                            <X size={24} />
                          </div>
                          <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest">Pass</span>
                        </button>
                        <button 
                          onClick={() => onSwipe('right', mentor.id)}
                          className="flex flex-col items-center gap-1 group/btn"
                        >
                          <div className="w-12 h-12 rounded-full border-2 border-emerald-100 flex items-center justify-center text-emerald-500 bg-emerald-50 group-hover/btn:bg-emerald-500 group-hover/btn:text-white transition-all">
                            <Heart size={24} />
                          </div>
                          <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest">Like</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </TinderCard>
              ))}
            </div>
          ) : (
            <div className="text-center p-12 bg-white rounded-[3rem] border border-dashed border-neutral-300 max-w-md">
              <div className="w-20 h-20 bg-neutral-100 rounded-full flex items-center justify-center mx-auto mb-6 text-neutral-400">
                <Filter size={40} />
              </div>
              {!filters.branch && !filters.skill ? (
                <>
                  <h3 className="text-xl font-bold mb-2">Start your journey</h3>
                  <p className="text-neutral-500 text-sm">Please select a branch or skill to discover mentors tailored for you.</p>
                </>
              ) : (
                <>
                  <h3 className="text-xl font-bold mb-2">No more mentors found</h3>
                  <p className="text-neutral-500 text-sm">Try adjusting your filters or check back later for new masters joining the bridge.</p>
                  <button 
                    onClick={() => setFilters({ branch: '', skill: '' })}
                    className="mt-6 px-6 py-2 bg-indigo-600 text-white rounded-xl font-bold text-sm hover:bg-indigo-700 transition-colors"
                  >
                    Reset Filters
                  </button>
                </>
              )}
            </div>
          )}
        </div>
      </div>
      <StudentChatbot studentBranch={user.branch} studentSkills={user.skills || []} />
    </div>
  );
}
