import { User } from '../types';
import { LogOut, Home, User as UserIcon } from 'lucide-react';

interface NavbarProps {
  user: User;
  onLogout: () => void;
  onHome: () => void;
}

export default function Navbar({ user, onLogout, onHome }: NavbarProps) {
  return (
    <nav className="bg-white border-b border-neutral-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        <div 
          className="flex items-center gap-2 cursor-pointer group"
          onClick={onHome}
        >
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-bold text-xl group-hover:scale-105 transition-transform">
            V
          </div>
          <span className="font-bold text-xl tracking-tight hidden sm:block">
            MentorBridge
          </span>
        </div>

        <div className="flex items-center gap-6">
          <button 
            onClick={onHome}
            className="p-2 text-neutral-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
            title="Home"
          >
            <Home size={24} />
          </button>
          
          <div className="flex items-center gap-3 pl-6 border-l border-neutral-200">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-semibold">{user.name}</p>
              <p className="text-xs text-neutral-500 capitalize">{user.role}</p>
            </div>
            <div className="w-10 h-10 bg-neutral-100 rounded-full flex items-center justify-center text-neutral-600 border border-neutral-200">
              {user.profilePic ? (
                <img src={user.profilePic} alt={user.name} className="w-full h-full rounded-full object-cover" />
              ) : (
                <UserIcon size={20} />
              )}
            </div>
            <button 
              onClick={onLogout}
              className="p-2 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              title="Logout"
            >
              <LogOut size={20} />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
